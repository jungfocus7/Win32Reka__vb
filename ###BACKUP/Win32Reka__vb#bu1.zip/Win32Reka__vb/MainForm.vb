﻿Imports System
Imports Win32Reka__vb.Helper

Public NotInheritable Class MainForm
    Public Shared ReadOnly Title As String = $"{GetType(MainForm).Namespace}  v1.02"




    Public Sub New()
        ' 디자이너에서 이 호출이 필요합니다.
        InitializeComponent()

        ' InitializeComponent() 호출 뒤에 초기화 코드를 추가하세요.

    End Sub


    Protected Overrides Sub OnLoad(ea As EventArgs)
        MyBase.OnLoad(ea)

        Text = Title



        AddHandler m_btn70.Click,
            Sub()
                MessageBoxHelper.Show_a(Handle, "개발자 퍼포먼스가 연결됨")
            End Sub
    End Sub

End Class
