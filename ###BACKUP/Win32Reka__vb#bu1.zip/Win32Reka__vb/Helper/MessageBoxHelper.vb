﻿Imports System
Imports System.Runtime.InteropServices



Namespace Helper
    Public NotInheritable Class MessageBoxHelper
        Private Sub New()
        End Sub


        Private Const _dfpCommon As String = ".\Win32Common.dll"

        'fn_MessageBox(HWND hWnd, LPCSTR lpText, LPCSTR lpCaption, UINT uType)
        <DllImport(_dfpCommon, EntryPoint:="fn_MessageBox", CharSet:=CharSet.Ansi, SetLastError:=True)>
        Private Shared Function fn_MessageBox(
            hWnd As IntPtr, lpText As String, lpCaption As String, uType As UInteger) As Integer
        End Function


        Public Shared Caption As String = "[Notify]"


        Public Shared Function Show(
            hWnd As IntPtr, lpText As String, lpCaption As String, uType As UInteger) As Integer
            Return fn_MessageBox(hWnd, lpText, lpCaption, uType)
        End Function


        Public Shared Function Show_a(hWnd As IntPtr, lpText As String) As Integer
            Dim lpCaption As String = Caption
            Dim uType As UInteger = EMsgBoxUType.MB_OK
            Return fn_MessageBox(hWnd, lpText, lpCaption, uType)
        End Function


        'Private Shared Function EnumThreadProc(hWnd As IntPtr, lParam As IntPtr) As Boolean
        '    Return False
        'End Function


        'Private Shared Sub InvokeProc()

        'End Sub

    End Class
End Namespace