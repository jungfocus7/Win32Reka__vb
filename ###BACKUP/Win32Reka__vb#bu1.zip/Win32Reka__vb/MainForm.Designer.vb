﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class MainForm
    Inherits System.Windows.Forms.Form

    'Form은 Dispose를 재정의하여 구성 요소 목록을 정리합니다.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows Form 디자이너에 필요합니다.
    Private components As System.ComponentModel.IContainer

    '참고: 다음 프로시저는 Windows Form 디자이너에 필요합니다.
    '수정하려면 Windows Form 디자이너를 사용하십시오.  
    '코드 편집기에서는 수정하지 마세요.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.m_btn72 = New System.Windows.Forms.Button()
        Me.m_btn71 = New System.Windows.Forms.Button()
        Me.m_btn70 = New System.Windows.Forms.Button()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.m_txb21 = New System.Windows.Forms.TextBox()
        Me.m_txb22 = New System.Windows.Forms.TextBox()
        Me.m_txb23 = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.m_txb41 = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.m_txb42 = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.m_ckb73 = New System.Windows.Forms.CheckBox()
        Me.m_txb5Left = New System.Windows.Forms.TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.m_txb5Top = New System.Windows.Forms.TextBox()
        Me.m_txb5Width = New System.Windows.Forms.TextBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.m_txb5Height = New System.Windows.Forms.TextBox()
        Me.m_txb31 = New System.Windows.Forms.TextBox()
        Me.m_txb32 = New System.Windows.Forms.TextBox()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.m_ckb61 = New System.Windows.Forms.CheckBox()
        Me.m_ckb62 = New System.Windows.Forms.CheckBox()
        Me.m_ckb63 = New System.Windows.Forms.CheckBox()
        Me.m_ckb64 = New System.Windows.Forms.CheckBox()
        Me.m_btn31 = New System.Windows.Forms.Button()
        Me.m_btn32 = New System.Windows.Forms.Button()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'm_btn72
        '
        Me.m_btn72.Cursor = System.Windows.Forms.Cursors.Hand
        Me.m_btn72.Font = New System.Drawing.Font("맑은 고딕", 7.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.m_btn72.Location = New System.Drawing.Point(314, 364)
        Me.m_btn72.Name = "m_btn72"
        Me.m_btn72.Size = New System.Drawing.Size(74, 24)
        Me.m_btn72.TabIndex = 20
        Me.m_btn72.Text = "CLEAR"
        Me.m_btn72.UseVisualStyleBackColor = True
        '
        'm_btn71
        '
        Me.m_btn71.Cursor = System.Windows.Forms.Cursors.Hand
        Me.m_btn71.Font = New System.Drawing.Font("맑은 고딕", 7.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.m_btn71.Location = New System.Drawing.Point(234, 364)
        Me.m_btn71.Name = "m_btn71"
        Me.m_btn71.Size = New System.Drawing.Size(74, 24)
        Me.m_btn71.TabIndex = 19
        Me.m_btn71.Text = "APPLY"
        Me.m_btn71.UseVisualStyleBackColor = True
        '
        'm_btn70
        '
        Me.m_btn70.Cursor = System.Windows.Forms.Cursors.Hand
        Me.m_btn70.Font = New System.Drawing.Font("맑은 고딕", 7.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.m_btn70.Location = New System.Drawing.Point(12, 364)
        Me.m_btn70.Name = "m_btn70"
        Me.m_btn70.Size = New System.Drawing.Size(74, 24)
        Me.m_btn70.TabIndex = 17
        Me.m_btn70.Text = "FUNC"
        Me.m_btn70.UseVisualStyleBackColor = True
        '
        'PictureBox1
        '
        Me.PictureBox1.BackColor = System.Drawing.Color.Black
        Me.PictureBox1.Cursor = System.Windows.Forms.Cursors.Hand
        Me.PictureBox1.Location = New System.Drawing.Point(12, 12)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(80, 80)
        Me.PictureBox1.TabIndex = 3
        Me.PictureBox1.TabStop = False
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("맑은 고딕", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.Label1.Location = New System.Drawing.Point(12, 176)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(56, 15)
        Me.Label1.TabIndex = 4
        Me.Label1.Text = "Caption: "
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("맑은 고딕", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.Label2.Location = New System.Drawing.Point(98, 15)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(52, 15)
        Me.Label2.TabIndex = 5
        Me.Label2.Text = "Handle: "
        '
        'm_txb21
        '
        Me.m_txb21.Location = New System.Drawing.Point(190, 12)
        Me.m_txb21.Name = "m_txb21"
        Me.m_txb21.ReadOnly = True
        Me.m_txb21.Size = New System.Drawing.Size(190, 23)
        Me.m_txb21.TabIndex = 0
        '
        'm_txb22
        '
        Me.m_txb22.Location = New System.Drawing.Point(190, 41)
        Me.m_txb22.Name = "m_txb22"
        Me.m_txb22.ReadOnly = True
        Me.m_txb22.Size = New System.Drawing.Size(190, 23)
        Me.m_txb22.TabIndex = 1
        '
        'm_txb23
        '
        Me.m_txb23.Location = New System.Drawing.Point(190, 70)
        Me.m_txb23.Name = "m_txb23"
        Me.m_txb23.ReadOnly = True
        Me.m_txb23.Size = New System.Drawing.Size(190, 23)
        Me.m_txb23.TabIndex = 2
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("맑은 고딕", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.Label3.Location = New System.Drawing.Point(98, 44)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(73, 15)
        Me.Label3.TabIndex = 9
        Me.Label3.Text = "ClassName: "
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("맑은 고딕", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.Label4.Location = New System.Drawing.Point(98, 73)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(86, 15)
        Me.Label4.TabIndex = 10
        Me.Label4.Text = "ProcessName: "
        '
        'm_txb41
        '
        Me.m_txb41.Location = New System.Drawing.Point(74, 173)
        Me.m_txb41.Name = "m_txb41"
        Me.m_txb41.Size = New System.Drawing.Size(300, 23)
        Me.m_txb41.TabIndex = 7
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("맑은 고딕", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.Label5.Location = New System.Drawing.Point(12, 205)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(55, 15)
        Me.Label5.TabIndex = 12
        Me.Label5.Text = "Opacity: "
        '
        'm_txb42
        '
        Me.m_txb42.Location = New System.Drawing.Point(74, 202)
        Me.m_txb42.Name = "m_txb42"
        Me.m_txb42.Size = New System.Drawing.Size(54, 23)
        Me.m_txb42.TabIndex = 8
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("맑은 고딕", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.Label6.Location = New System.Drawing.Point(12, 236)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(34, 15)
        Me.Label6.TabIndex = 14
        Me.Label6.Text = "Left: "
        '
        'm_ckb73
        '
        Me.m_ckb73.AutoSize = True
        Me.m_ckb73.Font = New System.Drawing.Font("맑은 고딕", 7.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.m_ckb73.Location = New System.Drawing.Point(182, 369)
        Me.m_ckb73.Name = "m_ckb73"
        Me.m_ckb73.Size = New System.Drawing.Size(46, 16)
        Me.m_ckb73.TabIndex = 18
        Me.m_ckb73.Text = "Auto"
        Me.m_ckb73.UseVisualStyleBackColor = True
        '
        'm_txb5Left
        '
        Me.m_txb5Left.Location = New System.Drawing.Point(64, 233)
        Me.m_txb5Left.Name = "m_txb5Left"
        Me.m_txb5Left.Size = New System.Drawing.Size(54, 23)
        Me.m_txb5Left.TabIndex = 9
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("맑은 고딕", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.Label7.Location = New System.Drawing.Point(128, 236)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(34, 15)
        Me.Label7.TabIndex = 17
        Me.Label7.Text = "Top: "
        '
        'm_txb5Top
        '
        Me.m_txb5Top.Location = New System.Drawing.Point(184, 233)
        Me.m_txb5Top.Name = "m_txb5Top"
        Me.m_txb5Top.Size = New System.Drawing.Size(54, 23)
        Me.m_txb5Top.TabIndex = 10
        '
        'm_txb5Width
        '
        Me.m_txb5Width.Location = New System.Drawing.Point(64, 262)
        Me.m_txb5Width.Name = "m_txb5Width"
        Me.m_txb5Width.Size = New System.Drawing.Size(54, 23)
        Me.m_txb5Width.TabIndex = 11
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("맑은 고딕", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.Label8.Location = New System.Drawing.Point(12, 265)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(46, 15)
        Me.Label8.TabIndex = 20
        Me.Label8.Text = "Width: "
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("맑은 고딕", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.Label9.Location = New System.Drawing.Point(128, 265)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(50, 15)
        Me.Label9.TabIndex = 21
        Me.Label9.Text = "Height: "
        '
        'm_txb5Height
        '
        Me.m_txb5Height.Location = New System.Drawing.Point(184, 262)
        Me.m_txb5Height.Name = "m_txb5Height"
        Me.m_txb5Height.Size = New System.Drawing.Size(54, 23)
        Me.m_txb5Height.TabIndex = 12
        '
        'm_txb31
        '
        Me.m_txb31.Location = New System.Drawing.Point(74, 106)
        Me.m_txb31.Name = "m_txb31"
        Me.m_txb31.ReadOnly = True
        Me.m_txb31.Size = New System.Drawing.Size(200, 23)
        Me.m_txb31.TabIndex = 3
        '
        'm_txb32
        '
        Me.m_txb32.Location = New System.Drawing.Point(74, 135)
        Me.m_txb32.Name = "m_txb32"
        Me.m_txb32.ReadOnly = True
        Me.m_txb32.Size = New System.Drawing.Size(200, 23)
        Me.m_txb32.TabIndex = 5
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("맑은 고딕", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.Label10.Location = New System.Drawing.Point(12, 109)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(40, 15)
        Me.Label10.TabIndex = 25
        Me.Label10.Text = "Style: "
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Font = New System.Drawing.Font("맑은 고딕", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.Label11.Location = New System.Drawing.Point(12, 138)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(52, 15)
        Me.Label11.TabIndex = 26
        Me.Label11.Text = "StyleEx: "
        '
        'm_ckb61
        '
        Me.m_ckb61.AutoSize = True
        Me.m_ckb61.Cursor = System.Windows.Forms.Cursors.Hand
        Me.m_ckb61.Font = New System.Drawing.Font("맑은 고딕", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.m_ckb61.Location = New System.Drawing.Point(15, 301)
        Me.m_ckb61.Name = "m_ckb61"
        Me.m_ckb61.Size = New System.Drawing.Size(96, 19)
        Me.m_ckb61.TabIndex = 13
        Me.m_ckb61.Text = "MinimizeBox"
        Me.m_ckb61.UseVisualStyleBackColor = True
        '
        'm_ckb62
        '
        Me.m_ckb62.AutoSize = True
        Me.m_ckb62.Cursor = System.Windows.Forms.Cursors.Hand
        Me.m_ckb62.Font = New System.Drawing.Font("맑은 고딕", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.m_ckb62.Location = New System.Drawing.Point(123, 301)
        Me.m_ckb62.Name = "m_ckb62"
        Me.m_ckb62.Size = New System.Drawing.Size(98, 19)
        Me.m_ckb62.TabIndex = 14
        Me.m_ckb62.Text = "MaximizeBox"
        Me.m_ckb62.UseVisualStyleBackColor = True
        '
        'm_ckb63
        '
        Me.m_ckb63.AutoSize = True
        Me.m_ckb63.Cursor = System.Windows.Forms.Cursors.Hand
        Me.m_ckb63.Font = New System.Drawing.Font("맑은 고딕", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.m_ckb63.Location = New System.Drawing.Point(233, 301)
        Me.m_ckb63.Name = "m_ckb63"
        Me.m_ckb63.Size = New System.Drawing.Size(75, 19)
        Me.m_ckb63.TabIndex = 15
        Me.m_ckb63.Text = "Resizable"
        Me.m_ckb63.UseVisualStyleBackColor = True
        '
        'm_ckb64
        '
        Me.m_ckb64.AutoSize = True
        Me.m_ckb64.Cursor = System.Windows.Forms.Cursors.Hand
        Me.m_ckb64.Font = New System.Drawing.Font("맑은 고딕", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.m_ckb64.Location = New System.Drawing.Point(15, 326)
        Me.m_ckb64.Name = "m_ckb64"
        Me.m_ckb64.Size = New System.Drawing.Size(73, 19)
        Me.m_ckb64.TabIndex = 16
        Me.m_ckb64.Text = "TopMost"
        Me.m_ckb64.UseVisualStyleBackColor = True
        '
        'm_btn31
        '
        Me.m_btn31.Cursor = System.Windows.Forms.Cursors.Hand
        Me.m_btn31.Font = New System.Drawing.Font("맑은 고딕", 7.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.m_btn31.Location = New System.Drawing.Point(280, 106)
        Me.m_btn31.Name = "m_btn31"
        Me.m_btn31.Size = New System.Drawing.Size(50, 24)
        Me.m_btn31.TabIndex = 4
        Me.m_btn31.Text = "EDIT"
        Me.m_btn31.UseVisualStyleBackColor = True
        '
        'm_btn32
        '
        Me.m_btn32.Cursor = System.Windows.Forms.Cursors.Hand
        Me.m_btn32.Font = New System.Drawing.Font("맑은 고딕", 7.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.m_btn32.Location = New System.Drawing.Point(280, 135)
        Me.m_btn32.Name = "m_btn32"
        Me.m_btn32.Size = New System.Drawing.Size(50, 24)
        Me.m_btn32.TabIndex = 6
        Me.m_btn32.Text = "EDIT"
        Me.m_btn32.UseVisualStyleBackColor = True
        '
        'MainForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(400, 400)
        Me.Controls.Add(Me.m_btn32)
        Me.Controls.Add(Me.m_btn31)
        Me.Controls.Add(Me.m_ckb64)
        Me.Controls.Add(Me.m_ckb63)
        Me.Controls.Add(Me.m_ckb62)
        Me.Controls.Add(Me.m_ckb61)
        Me.Controls.Add(Me.Label11)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.m_txb32)
        Me.Controls.Add(Me.m_txb31)
        Me.Controls.Add(Me.m_txb5Height)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.m_txb5Width)
        Me.Controls.Add(Me.m_txb5Top)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.m_txb5Left)
        Me.Controls.Add(Me.m_ckb73)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.m_txb42)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.m_txb41)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.m_txb23)
        Me.Controls.Add(Me.m_txb22)
        Me.Controls.Add(Me.m_txb21)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.m_btn70)
        Me.Controls.Add(Me.m_btn71)
        Me.Controls.Add(Me.m_btn72)
        Me.Font = New System.Drawing.Font("맑은 고딕", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(129, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Location = New System.Drawing.Point(100, 40)
        Me.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.MaximizeBox = False
        Me.Name = "MainForm"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.Manual
        Me.Text = "Form1"
        Me.TopMost = True
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents m_btn72 As System.Windows.Forms.Button
    Friend WithEvents m_btn71 As System.Windows.Forms.Button
    Friend WithEvents m_btn70 As System.Windows.Forms.Button
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents m_txb21 As System.Windows.Forms.TextBox
    Friend WithEvents m_txb22 As System.Windows.Forms.TextBox
    Friend WithEvents m_txb23 As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents m_txb41 As System.Windows.Forms.TextBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents m_txb42 As System.Windows.Forms.TextBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents m_ckb73 As System.Windows.Forms.CheckBox
    Friend WithEvents m_txb5Left As System.Windows.Forms.TextBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents m_txb5Top As System.Windows.Forms.TextBox
    Friend WithEvents m_txb5Width As System.Windows.Forms.TextBox
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents m_txb5Height As System.Windows.Forms.TextBox
    Friend WithEvents m_txb31 As System.Windows.Forms.TextBox
    Friend WithEvents m_txb32 As System.Windows.Forms.TextBox
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents m_ckb61 As System.Windows.Forms.CheckBox
    Friend WithEvents m_ckb62 As System.Windows.Forms.CheckBox
    Friend WithEvents m_ckb63 As System.Windows.Forms.CheckBox
    Friend WithEvents m_ckb64 As System.Windows.Forms.CheckBox
    Friend WithEvents m_btn31 As System.Windows.Forms.Button
    Friend WithEvents m_btn32 As System.Windows.Forms.Button
End Class
