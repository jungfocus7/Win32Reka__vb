﻿#include "pch.h"



HHOOK g_hHook = nullptr;
LRESULT CALLBACK fn_HookProc(int nCode, WPARAM wParam, LPARAM lParam)
{
	if (nCode == HCBT_CREATEWND)
	{
		LPCBT_CREATEWND lpcWnd = (LPCBT_CREATEWND)lParam;
		LPCREATESTRUCTA lpcs = lpcWnd->lpcs;

		if (lpcs->lpszClass == (LPCSTR)(ATOM)32770)  // #32770 = dialog box class
		{
			RECT rcp{ };
			GetWindowRect(lpcs->hwndParent, &rcp);
			lpcs->x = rcp.left + ((rcp.right - rcp.left) - lpcs->cx) / 2;
			lpcs->y = rcp.top + ((rcp.bottom - rcp.top) - lpcs->cy) / 2;
		}
	}

	LRESULT lrs = CallNextHookEx(g_hHook, nCode, wParam, lParam);
	return lrs;
}


EXPORTED_METHOD int WINAPI fn_MessageBox(HWND hWnd, LPCSTR lpText, LPCSTR lpCaption, UINT uType)
{
	const DWORD dwThreadId = GetCurrentThreadId();
	g_hHook = SetWindowsHookExA(WH_CBT, fn_HookProc, nullptr, dwThreadId);

	int nRes = MessageBoxExA(hWnd, lpText, lpCaption, uType, 0);
	UnhookWindowsHookEx(g_hHook);

	return nRes;
}

