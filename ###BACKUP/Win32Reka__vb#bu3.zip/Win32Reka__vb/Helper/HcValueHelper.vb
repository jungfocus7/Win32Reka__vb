﻿Imports System
Imports System.Windows.Forms



Namespace Helper
    Public NotInheritable Class HcValueHelper
        Private Sub New()
        End Sub


        Public Shared Function ToText(txb As TextBox) As String
            Dim val As String = txb.Text
            If String.IsNullOrWhiteSpace(Val) Then
                Return String.Empty
            Else
                Return val
            End If
        End Function


        Public Shared Function ToOpacity(txb As TextBox) As Byte
            Const MinVal As Byte = 30

            Dim val As Byte
            Try
                val = Convert.ToByte(txb.Text)
                If val < MinVal Then
                    val = MinVal
                    txb.Text = val.ToString()
                End If
                Return val
            Catch
                val = MinVal
                txb.Text = val.ToString()
                Return val
            End Try
        End Function


        Public Shared Function ToInteger(txb As TextBox) As Integer
            Dim val As Integer
            Try
                val = Convert.ToInt32(txb.Text)
                Return val
            Catch
                val = 0
                Return val
            End Try
        End Function

    End Class
End Namespace
