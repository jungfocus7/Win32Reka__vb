﻿Imports System
Imports System.Runtime.CompilerServices



Namespace Helper
    'Public Module HmStringExtension
    '    <Extension()>
    '    Public Function ToValue(val As String) As String
    '        If String.IsNullOrWhiteSpace(val) Then
    '            Return String.Empty
    '        Else
    '            Return val
    '        End If
    '    End Function


    '    <Extension()>
    '    Public Function ToByte(val As String) As Byte
    '        Try
    '            Return Convert.ToByte(val)
    '        Catch
    '            Return Byte.MinValue
    '        End Try
    '    End Function
    'End Module
End Namespace